package com.example.dataextraction

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
